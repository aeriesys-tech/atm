module.exports = {
  mongodb: {
    url: 'mongodb+srv://richa:BT6t4UA9P2RsjGxX@cluster0.heipx1q.mongodb.net/atm-demo',
    databaseName: 'atm-demo',
    options: {
      // Removed deprecated options
    },
  },
  migrationsDir: 'migrations',
  changelogCollectionName: 'changelog',
};